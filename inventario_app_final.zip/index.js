const express = require("express");
const multer = require("multer");
const XLSX = require("xlsx");
const fs = require("fs");
const path = require("path");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static("public"));

const upload = multer({ dest: "uploads/" });
const INVENTARIO_FILE = path.join(__dirname, "inventario.json");
const BATCH_SIZE = 500; // process in chunks

if (!fs.existsSync(INVENTARIO_FILE)) {
  fs.writeFileSync(INVENTARIO_FILE, JSON.stringify([], null, 2));
}

function readInventario() {
  try { return JSON.parse(fs.readFileSync(INVENTARIO_FILE, "utf-8")); } catch (e) { return []; }
}
function writeInventario(arr) { fs.writeFileSync(INVENTARIO_FILE, JSON.stringify(arr, null, 2)); }

app.get("/inventario", (req, res) => { const inv = readInventario(); res.json(inv); });

app.post("/upload", upload.single("file"), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: "No file uploaded" });
  const filePath = req.file.path;
  try {
    const workbook = XLSX.readFile(filePath, { cellDates: true });
    const sheetName = workbook.SheetNames[0];
    const sheet = workbook.Sheets[sheetName];
    const rows = XLSX.utils.sheet_to_json(sheet, { defval: "" });

    const expected = {
      codigo: ["Material","material","Código","Codigo","MATERIAL"],
      nombre: ["Texto breve material (idioma trabajo)","Texto breve material","Nombre","NOMBRE"],
      ubicacion: ["Ubicación","Ubicacion","ubicación","UBICACIÓN","Location"],
      stock: ["Ctd.stock","Ctd stock","Stock","STOCK","Cantidad"],
      tipo: ["Tp.M","Tp. M","Tp_M","TpM","Tp.M."]
    };

    function findKey(keys, rowKeys) {
      for (const k of keys) {
        for (const rk of rowKeys) {
          if (rk.trim().toLowerCase() === k.trim().toLowerCase()) return rk;
        }
      }
      return null;
    }

    const rowKeys = rows.length ? Object.keys(rows[0]) : [];
    const map = {
      codigo: findKey(expected.codigo, rowKeys),
      nombre: findKey(expected.nombre, rowKeys),
      ubicacion: findKey(expected.ubicacion, rowKeys),
      stock: findKey(expected.stock, rowKeys),
      tipo: findKey(expected.tipo, rowKeys)
    };

    const missing = [];
    if (!map.nombre) missing.push("Texto breve material (nombre)");
    if (!map.codigo) missing.push("Material (código)");
    if (!map.tipo) missing.push("Tp.M (tipo de material)");
    if (missing.length) return res.status(400).json({ error: "Columnas faltantes", missing });

    let inventario = readInventario();
    const errors = [];
    let imported = 0;

    for (let i = 0; i < rows.length; i += BATCH_SIZE) {
      const batch = rows.slice(i, i + BATCH_SIZE);
      for (let r = 0; r < batch.length; r++) {
        const row = batch[r];
        const rawCodigo = String(row[map.codigo] || "").trim();
        const rawNombre = String(row[map.nombre] || "").trim();
        const rawTipo = String(row[map.tipo] || "").trim().toUpperCase();
        const rawUbic = String(row[map.ubicacion] || "").trim();
        const rawStock = row[map.stock] !== undefined ? row[map.stock] : "";

        const lineNumber = i + r + 2;
        if (!rawNombre) { errors.push({ line: lineNumber, error: "Nombre vacío" }); continue; }
        if (!rawCodigo) { errors.push({ line: lineNumber, error: "Código (Material) vacío" }); continue; }
        if (!["ERSA","UNBW"].includes(rawTipo)) { errors.push({ line: lineNumber, error: `Tipo inválido: '${rawTipo}'` }); continue; }
        const stockNum = Number(rawStock) || 0;

        const existingIndex = inventario.findIndex(it => String(it.codigo) === rawCodigo);
        if (existingIndex >= 0) {
          inventario[existingIndex] = { ...inventario[existingIndex], nombre: rawNombre, tipo: rawTipo, ubicacion: rawUbic, stock: stockNum };
        } else {
          inventario.push({ id: inventario.length + 1, codigo: rawCodigo, nombre: rawNombre, tipo: rawTipo, ubicacion: rawUbic, stock: stockNum, foto: "" });
        }
        imported++;
      }
      writeInventario(inventario);
    }

    fs.unlinkSync(filePath);
    return res.json({ imported, errors, totalRows: rows.length });
  } catch (err) {
    console.error(err);
    if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
    return res.status(500).json({ error: "Error procesando archivo", detail: String(err) });
  }
});

app.get("/", (req, res) => { res.sendFile(path.join(__dirname, "public", "index.html")); });
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => { console.log(`Server running on port ${PORT}`); });
