Inventario App - Importación Excel masiva

Instrucciones rápidas:

1. Instala dependencias:
   npm install

2. Ejecuta la app:
   npm start

3. Abre en tu navegador:
   http://localhost:3000

Funcionamiento:
- En la página principal puedes subir un archivo Excel (.xlsx).
- El importador busca columnas por nombres comunes y mapea:
  - "Texto breve material (idioma trabajo)" -> nombre
  - "Material" -> codigo
  - "Ubicación" -> ubicacion
  - "Ctd.stock" -> stock
  - "Tp.M" -> tipo (debe ser ERSA o UNBW)
- Se procesa en lotes para manejar archivos grandes.
- Al finalizar muestra un modal visible con resumen (imported, errors).
- El inventario se guarda en inventario.json en la raíz del proyecto.
